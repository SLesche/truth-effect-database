prep_within_data <- function(within_data, db_overview){
  
  return(within_data)
}